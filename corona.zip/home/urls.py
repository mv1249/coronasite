from django.contrib import admin
from django.urls import path,include
from home import views
urlpatterns = [
    path("",views.index,name='home'),
    path("symptoms",views.symptoms,name='symptoms'),
    path("stats",views.stats,name='stats'),
    path("preventions",views.preventions,name='preventions'),
    path("hero",views.hero,name='hero'),
     path("details",views.details,name='details'),
]
