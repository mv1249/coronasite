from django.contrib import admin
from home.models import patients
# Register your models here.
admin.site.register(patients)