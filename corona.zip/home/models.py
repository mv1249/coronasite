from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class patients(models.Model):
    name=models.CharField(max_length=122,null=True,blank=True)
    address=models.CharField(max_length=122,null=True,blank=True)
    pno=models.CharField(max_length=12,null=True,blank=True)
    fever=models.CharField(max_length=122,null=True)
    runnose=models.CharField(max_length=122,null=True)
    throat=models.CharField(max_length=122,null=True)
    temp=models.CharField(max_length=12,null=True)
    hosname=models.CharField(max_length=122,null=True)
    date=models.DateField()
    def __str__(self):
        return self.name
    