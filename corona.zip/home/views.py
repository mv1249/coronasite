from django.shortcuts import render,HttpResponse
from datetime import datetime
from home.models import patients
from django.contrib import messages
# Create your views here.
def index(request):    #request bhejna is sabse important!!!
    return render(request,'index.html')
def symptoms(request):
    return render(request,'symptoms.html')
def stats(request):
    return render(request,'stats.html')
def preventions(request):
    return render(request,'preventions.html')
def hero(request):
    return render(request,'hero.html')
def details(request):
    if request.method=="POST":     #agar koi aapko request karta hai "post" through tab ye kaam karna..
         name=request.POST.get('name')  #request.post meri dictionary hai..aur vaha se maine naam uthaya hai
         address=request.POST.get('address')
         pno=request.POST.get('phone number')
         fever=request.POST.get('fever')
         runnose=request.POST.get('running nose') 
         throat=request.POST.get('throat pain')
         temp=request.POST.get('Temprature')
         hosname=request.POST.get('Hospitals visited')
         con=patients(name=name,address=address,pno=pno,fever=fever,runnose=runnose,throat=throat,temp=temp,hosname=hosname,date=datetime.today())
         con.save()
         messages.success(request, 'your message has been sent!')
    return render(request,'details.html')